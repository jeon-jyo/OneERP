package com.springboot.team_one.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springboot.team_one.dto.AssembleDTO;
import com.springboot.team_one.service.VUEService;

@Controller
public class ControllerVUE {
	
	@Autowired
	VUEService vueService;
	
	private static final Logger logger = LoggerFactory.getLogger(ControllerVUE.class);
	
	// 인사 VUE========================================
	// 부서목록
	@CrossOrigin
    @ResponseBody
	@RequestMapping(value="dept_list.vue")
	public List<AssembleDTO> dept_list(HttpServletRequest req, Model model){
		logger.info("[url : dept_list.vue]");
		
		return vueService.dept_list(req, model);
	}
	// 인사카드 목록
	@CrossOrigin
    @ResponseBody
    @RequestMapping(value="emp_list.vue")
    public List<AssembleDTO> emp_list(HttpServletRequest req, Model model){
    	logger.info("[url : emp_list.vue]");
      
    	return vueService.emp_list(req, model);
    }
    
	// 회계 VUE=========================================
	// 재무상태표 접근
	// http://localhost:8086/financial_statement.vue
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="financial_statement.vue")
	public AssembleDTO financial_statement(HttpServletRequest req, Model model) {
    	logger.info("[url : financial_statement.vue]");
	      
    	return vueService.financial_statement(req, model);
	}
    // 손익계산서 접근
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="financial_income_statement.vue")
	public AssembleDTO financial_income_statement(HttpServletRequest req, Model model) {
    	logger.info("[url : financial_income_statement.vue]");
    	
    	return vueService.financial_income_statement(req, model);
	}
    
	// 구매 VUE=========================================
	// 주문서 목록
 	@CrossOrigin
 	@ResponseBody
 	@RequestMapping(value="purchase_in_list.vue")
 	public List<AssembleDTO> purchase_in_list(HttpServletRequest req, Model model) {
 		logger.info("[url : purchase_in_list.vue]");
 		return vueService.purchase_in_list(req, model);
 	}
 	
	// 판매 VUE=========================================
    // 매출장 목록
   	@CrossOrigin
   	@ResponseBody
   	@RequestMapping(value="purchase_out_list.vue")
   	public List<AssembleDTO> purchase_out_list(HttpServletRequest req, Model model) {
   		logger.info("[url : purchase_out_list.vue]");
   	   
   		return vueService.purchase_out_list(req, model);
   	}
   	
	// 물류 VUE=========================================
	// 창고 목록
    @CrossOrigin
    @ResponseBody
    @RequestMapping(value="warehouse_list.vue")
    public List<AssembleDTO> warehouse_list_vue(HttpServletRequest req, Model model) {
    	logger.info("[url : warehouse_list.vue]");
    	
    	return vueService.warehouseList_vue(req, model);
    }
    
    // 출고 내역
 	@CrossOrigin
 	@ResponseBody
 	@RequestMapping(value="release_history_list.vue")
 	public List<AssembleDTO> release_history_list(HttpServletRequest req, Model model) {
 		logger.info("[url : release_history_list.vue]");
 		return vueService.release_history_list(req, model);
 	}
	// 출/퇴근 VUE=========================================
	// 출/퇴근 목록
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value="vue_per_attend_list_call.vue")
	public List<AssembleDTO> vue_per_attend_list_call(HttpServletRequest req, Model model) {
		logger.info("[url : vue_per_attend_list_call.vue]");
		return vueService.vue_per_attend_list_call(req, model);
	}
	
}
