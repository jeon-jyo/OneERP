package com.springboot.team_one.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.springboot.team_one.dto.AssembleDTO;

public interface VUEService {
	
	// ================ 인사 ====================
	// 부서목록
	public List<AssembleDTO> dept_list(HttpServletRequest req, Model model);
	
	// 인사카드목록
	public List<AssembleDTO> emp_list(HttpServletRequest req, Model model);
	
	// ================ 회계 ====================
	// 재무상태표
	public AssembleDTO financial_statement(HttpServletRequest req, Model model);
	
	// 손익계산서
	public AssembleDTO financial_income_statement(HttpServletRequest req, Model model);
	
	// ================ 구매 ====================
	// 매입장
	public List<AssembleDTO> purchase_in_list(HttpServletRequest req, Model model);
	
	// ================ 판매 ====================
	// 매출장
	public List<AssembleDTO> purchase_out_list(HttpServletRequest req, Model model);
	
	// ================ 물류 ====================
	// 창고 목록
	public List<AssembleDTO> warehouseList_vue(HttpServletRequest req, Model model);
	
	// 출고 내역
	public List<AssembleDTO> release_history_list(HttpServletRequest req, Model model);
	// ================ 출/퇴근 ====================
	public List<AssembleDTO> vue_per_attend_list_call(HttpServletRequest req, Model model);
	
}
