package com.springboot.team_one.dao;

import java.util.List;
import com.springboot.team_one.dto.AssembleDTO;

public interface VUEDao {
	
	// ======================인사=======================
	// 부서목록
	public List<AssembleDTO> dept_list();
	
	// 인사카드목록
	public List<AssembleDTO> emp_list();
	
	// ======================회계=======================
	// ======= 재무상태표 =======
	// 보통예금
	public int bank_assets();
	
	// 매출채권
	public int trade_receivable();
	
	// 부가세대급금
	public int vat_payment();
	
	// 매입채무
	public int trade_payable();
	
	// 부가세예수금
	public int vat_deposit();
	
	// ======= 손익계산서 =======
	// 매출총액
	public int take_sales();
	
	// 기초상품 재고 입력일 조회
	public int beg_inven_select();
	
	// 기초상품 재고 입력일 조회
	public int beg_inven_insert(int cost);
	
	// 기초상품 재고액
	public int beginning_inventory();
	
	// 당기상품 재고액
	public int current_inventory();
	
	// 기말상품 재고액
	public int ending_inventory();
	
	// 급여총액
	public int total_salary();
	
	// 비용 계정별 검색
	public int all_expense_lookup(String subject);
	
	// 비과세 소득 합계
	public int non_tax_sum();
	
	// ======================판매=======================
	// 매출장 목록
	public List<AssembleDTO> purchase_out_list();
	
	// ======================구매=======================
	// 매입장 목록
	public List<AssembleDTO> purchase_in_list();
	
	// ======================물류=======================
	// 창고 목록
	public List<AssembleDTO> warehouseList();
	
	// 출고 내역
	public List<AssembleDTO> release_history_list();
	
	// ======================출/퇴근=======================
	// 출/퇴근 목록
	public List<AssembleDTO> vue_per_attdance_list();	
}
