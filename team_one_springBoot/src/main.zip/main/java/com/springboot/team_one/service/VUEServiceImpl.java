package com.springboot.team_one.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.springboot.team_one.dao.VUEDaoImpl;
import com.springboot.team_one.dto.AssembleDTO;
@Service
public class VUEServiceImpl implements VUEService {

	@Autowired
	VUEDaoImpl dao;
	
	// ===================인사=======================
	// 부서목록
	@Override
	public List<AssembleDTO> dept_list(HttpServletRequest req, Model model) {
		return dao.dept_list();
	}
	
	// 인사카드목록
	@Override
	public List<AssembleDTO> emp_list(HttpServletRequest req, Model model) {
		return dao.emp_list();
	}
	
	// ===================회계=======================
	// 재무상태표
	@Override
	public AssembleDTO financial_statement(HttpServletRequest req, Model model) {
		AssembleDTO financial_statement = new AssembleDTO();
		
		// ===========================================
		// 자산정보
		// 보통예금
		financial_statement.setBank_assets(dao.bank_assets());
		
		// 매출채권
		financial_statement.setTrade_receivable(dao.trade_receivable());
		
		// 부가세대급금
		financial_statement.setVat_payment(dao.vat_payment());
		
		// 재고자산
		financial_statement.setCurrent_inventory(dao.ending_inventory());
		// ===========================================
		// 부채정보
		// 매입채무Liabilities
		financial_statement.setTrade_payable(dao.trade_payable());
		
		// 부가세예수금
		financial_statement.setVat_deposit(dao.vat_deposit());
		
		model.addAttribute("financial_statement", financial_statement);
		return financial_statement;
	}
	
	// 손익계산서
	@Override
	public AssembleDTO financial_income_statement(HttpServletRequest req, Model model) {
		AssembleDTO financial_income = new AssembleDTO();
		
		// 현재 날짜 구하기 (시스템 시계, 시스템 타임존)
		LocalDate now = LocalDate.now();
		// 포맷 정의
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMM");
		// 포맷 적용
		int time = Integer.parseInt(now.format(format));
		
		// 현재재고액 조회
		int now_inven = dao.ending_inventory();
		// 기초상품재고 입력일 조회
		int beg_time = dao.beg_inven_select();
		
		// 기초상품재고 입력일 비교
		if((time - 1) > beg_time) {
			int beg_result = dao.beg_inven_insert(now_inven);
			System.out.println("기초상품재고 입력일 비교 : " + beg_result);
		}
		
		// 매출총액
		financial_income.setTake_sales(dao.take_sales());
		
		// 기초상품 재고액
		financial_income.setBeginning_inventory(dao.beginning_inventory());
		
		// 당기상품 재고액
		financial_income.setCurrent_inventory(dao.current_inventory());
		
		// 기말상품 재고액
		financial_income.setEnding_inventory(dao.ending_inventory());
		
		// ===========================================
		// 각 계정별 비용저장
		// 급여총액
		financial_income.setTotal_salary(dao.total_salary());
		
		// 여비교통비
		financial_income.setTravel_expense(dao.all_expense_lookup("여비교통비"));
		
		// 소모품비
		financial_income.setConsumable_expense(dao.all_expense_lookup("소모품비"));
		
		// 통신비
		financial_income.setCommunication_expense(dao.all_expense_lookup("통신비"));
		
		// 접대비
		financial_income.setEntertainment_expense(dao.all_expense_lookup("접대비"));
		
		// 수도광열비
		financial_income.setAdministrative_expense(dao.all_expense_lookup("수도광열비"));
		
		// 창고관리비
		financial_income.setWarehouse_expense(dao.all_expense_lookup("창고관리비"));
		
		// 비과세소득 합계
		financial_income.setNon_tax_sum(dao.non_tax_sum());
		
		model.addAttribute("financial_income", financial_income);
		return financial_income;
	}
	
	// ===================구매=======================
	// 매입장
	@Override
	public List<AssembleDTO> purchase_in_list(HttpServletRequest req, Model model) {
		return dao.purchase_in_list();
	}
	
	// ===================판매=======================
	// 매출장
	@Override
	public List<AssembleDTO> purchase_out_list(HttpServletRequest req, Model model) {
		return dao.purchase_out_list();
	}
	
	// ===================물류=======================
	//창고 목록
    @Override
    public List<AssembleDTO>  warehouseList_vue(HttpServletRequest req, Model model) {
    	return dao.warehouseList();
    }
    
    // 출고내역
    @Override
    public List<AssembleDTO> release_history_list(HttpServletRequest req, Model model) {
		List<AssembleDTO> list = dao.release_history_list();
		model.addAttribute(list);
		return list;
	}
    // ===================출/퇴근=======================
    @Override
	public List<AssembleDTO> vue_per_attend_list_call(HttpServletRequest req, Model model) {
		return dao.vue_per_attdance_list();
	}
}
